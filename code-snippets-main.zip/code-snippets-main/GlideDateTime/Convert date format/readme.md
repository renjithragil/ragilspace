# Convert date format

**Use-case / Requirement :**
Convert date from one format to another format
For example from dd-mm-yyyy to yyyy-mm-dd or yyyy/mm/dd etc

**Solution :**
Use GlideDate object and getByFormat method for conversion.
Check the script.js file to find the code
