//prefix with javascript: in default value field
//Add or Subtract a relative amount of days from today
javascript:var gdt = new GlideDateTime(); gdt.addDays(-1);gdt.getDate();
