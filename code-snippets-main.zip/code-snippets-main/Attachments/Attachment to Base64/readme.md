# Base64 file encoder

Convert attachment to Base64