Encode attachment to base64 for scoped applications. Uses the GlideSysAttachment API. 
Place of use: creating a spoke/integration where you need to send an attachment via REST.
