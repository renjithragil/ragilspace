# GlideSystem User Methods

### userID
* Description: Returns the sys_id of the user associated with this session.
* [userID Code Snippet](userID.js)
* [userID API Doc](https://developer.servicenow.com/dev.do#!/reference/api/rome/server_legacy/c_GlideSystemAPI#r_GS-userID)