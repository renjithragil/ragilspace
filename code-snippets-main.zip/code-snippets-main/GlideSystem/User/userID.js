var id = gs.userID(); //Returns the sys_id of the user associated with this session
gs.info(id);

//Example Output: 98b9c2ee1b356664a496154de4febcb
