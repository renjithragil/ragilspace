var now = gs.nowDateTime();
gs.info('Now: ' + now);
var yearsAgo = gs.yearsAgo(1); //Gets a date and time for a certain number of years ago.
gs.info('1 Year Ago: ' + yearsAgo);

//Output Example:
//*** Script: Now: 2021-10-05 08:54:28
//*** Script: 1 Year Ago: 2020-10-05 12:54:28
