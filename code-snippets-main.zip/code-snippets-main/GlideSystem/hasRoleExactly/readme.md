# Server-side version of the hasRoleExactly

Determines whether the current user has the specified role.

This feature only exists on the client-side but can be useful on the server-side also.
