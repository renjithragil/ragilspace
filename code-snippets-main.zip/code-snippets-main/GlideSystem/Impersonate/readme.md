GlideSystem (referred as "gs") provides a way to find information about the current session.
Using the getSession() method of the scoped GlideSystem API.

This gives the example on how to impersonate a user using the impersonate method in the code.
