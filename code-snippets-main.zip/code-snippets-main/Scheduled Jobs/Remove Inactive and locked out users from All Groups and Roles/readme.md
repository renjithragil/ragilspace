# Remove Inactive and locked out users from All Groups and Roles

It is always a good practise to have a secure and clean working instance. Having users with specific criteria such as the user is inactive and has been locked out should not have any role or belong to any group.