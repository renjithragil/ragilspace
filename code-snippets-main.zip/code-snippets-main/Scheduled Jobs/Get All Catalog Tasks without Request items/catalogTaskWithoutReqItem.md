# Fetch all Catalog tasks which do not have any Request items associated.

Get all the Catalog tasks which do not have any Request items, so that the requester can be notified and action can be taken.