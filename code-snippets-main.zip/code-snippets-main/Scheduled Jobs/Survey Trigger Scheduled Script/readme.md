## Use the code snippets to trigger survey via scheduled script. 

### Survey Trigger Scheduled Job
survey_trigger_sj.js

*Note:  Please update the query and sys_id as per the comments in the script*
