## Use the code snippets to trigger approval reminder notifications. 

### 1 Change Approval Reminder.
change_reminder_scheduled_job.js

### 2 Requested item approval reminder to approvers.
requested_item_approval_reminder_approver.js

### 3 Requested item approval reminder to requestor.
requested_item_approval_reminder_requestor.js

*Note: Notifications and Events to be configured sepearately.*
