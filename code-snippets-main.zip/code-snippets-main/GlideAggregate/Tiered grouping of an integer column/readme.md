# Tiered grouping of an integer column

If you have a column with points (as an integer), this script breaks them down by percentile tiers.
