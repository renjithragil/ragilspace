# Discover the data centers for all the cloud service accounts.
* Description: This script will discover the data centers for all the service accounts. 
> If you have a lot of service accounts, it is best to run the script as a *Scheduled Job*
* Motivation: Using the UI to discover the data centers is impractical if you have many service accounts. It could potentially take hours. This script will perform the task programmatically