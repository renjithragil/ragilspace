Allow Any Language Character Remove Special Characters, Can be used to verify valid names. Sorry Elon Musk's First born.
