Will accept a string and remove all newline (\n) and carriage return (\r) characters
