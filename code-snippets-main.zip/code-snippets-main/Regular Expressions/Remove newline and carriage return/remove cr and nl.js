var inputString  = "";                                      // insert your input string here
var outputString = inputString.replace(/[\r\n]/g, '');      // the processed string is returned in the outputString variable
