var reg = '/^\d{10}$/';  // Update the number based on the need

var k = '123456789144'; // example

 if (/^\d{10}$/.test(k)){ // This will check if it has 10 digits
  
}
