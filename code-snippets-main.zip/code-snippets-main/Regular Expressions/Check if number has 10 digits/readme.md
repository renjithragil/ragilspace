Script is used to check if the number has 10 digts( you can update the digit count in the code based on the need.
