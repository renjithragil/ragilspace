# Detect emoji in string

Use this script to detect if string contains emoji