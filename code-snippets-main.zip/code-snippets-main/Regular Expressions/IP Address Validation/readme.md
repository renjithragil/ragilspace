This regex validates for ip address(ipv4) based on the input.

Following are the valid IP address examples:

192.168.1.1

127.0.0.1

0.0.0.0

255.255.255.255

256.256.256.256

999.999.999.999

1.2.3

1.2.3.4

