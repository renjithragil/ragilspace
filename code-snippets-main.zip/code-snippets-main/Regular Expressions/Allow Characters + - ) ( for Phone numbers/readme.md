### Allows Characters +, -, (, ) for entering Phone Numbers

Allows characters useful for adding phone numbers in various formats like (+1) - 123 - 456 - 789, +1-978-654-362, (123) (567) (897) etc.
One can add more functionality to it, by controlling the number of digits added etc.
