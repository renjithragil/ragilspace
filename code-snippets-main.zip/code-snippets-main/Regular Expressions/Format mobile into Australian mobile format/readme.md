# Format phone into Australian mobile Format

Use this script to format a phone number from +61433394881 style to 0433 394 881 style.