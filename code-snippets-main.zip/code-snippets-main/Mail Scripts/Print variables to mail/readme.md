Script block to be used within a Notification Email Script or as a standalone one.
It prints all variables + answers of a catalog produced record to the email body, along with the short description of the task on top (please check script).
