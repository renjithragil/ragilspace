# Add Checklist

If a checklist exists for the task, add it to the email notification.
