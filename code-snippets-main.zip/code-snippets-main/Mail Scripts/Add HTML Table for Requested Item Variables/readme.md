Use this snippet to create an HTML file of requested item variables.  Will exclude variables that are not needed (empty/undefined)
