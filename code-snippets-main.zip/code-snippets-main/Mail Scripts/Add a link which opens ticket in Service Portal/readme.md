Use this script to add a link in email notification which opens the ticket in Service Portal 
