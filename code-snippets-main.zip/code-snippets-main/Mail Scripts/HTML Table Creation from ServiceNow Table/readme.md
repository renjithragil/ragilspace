This mail script uses a GlideRecord object to get values from a ServiceNow table and then format that information into an HTML table in a notification.

Replace "example_table" with your desired table.

Change the style tags to fit your desired results, like background-color, etc.
