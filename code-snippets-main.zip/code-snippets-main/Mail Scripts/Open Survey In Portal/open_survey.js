
 var survey = '<a href="' + gs.getProperty('glide.servlet.uri') + '/sp?id=take_survey&instance_id=' +current.sys_id + '">Click Here to take Survey </a>';  
 template.print(survey);
