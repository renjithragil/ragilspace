1)create a notification on "Assessment Instance" table</br>
2)when record is created and state is ready to take trigger notification to assigned to </br>
3)use this mail script to get the url to survey in the email that takes them to the portal</br>
