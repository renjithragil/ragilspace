# Translate your messages in client script using getMessage method

  *[getMessage() code snippet](getMessage.js)
  
  *[Translate message in client script doc](https://docs.servicenow.com/bundle/rome-platform-administration/page/administer/localization/task/t_TranslateAClientScriptMessage.html)
