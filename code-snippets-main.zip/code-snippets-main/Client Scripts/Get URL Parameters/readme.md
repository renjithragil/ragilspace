# Get URL Parameters in Global,Scoped Application for Record & Catalog Item

Many times there is a need to grab parameters from URL. This could be required at table form load or catalog item load and either in Global scope or custom scope application when redirection happened. Given script will help you in achieving this:

[Click here for the script](script.js)
