Use this script to make all fields readonly via client script.

**Tested in Global scope
**You can't make mandatory fields as readonly
**Best Practice is to use ACLs
