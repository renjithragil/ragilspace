This script is for an onChange client script

This is using an example where you have two date variables and need to ensure the user does not choose an end date that's before the start date

1. replace 'start_date' in the script with your actual start date field name
2. replace 'end_date' in the script with yoru actual start date field name
3. replace showFieldMsg and showErrorBox messages with your own message, if applicable

This script works for both the standard (desktop) UI and Service Portal
