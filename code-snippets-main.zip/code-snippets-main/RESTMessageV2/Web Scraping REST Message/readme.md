# Web Scraper REST Message

This snippet shows how you would use RESTMessageV2 to scrape HTML from a website using a GET HTTP request.