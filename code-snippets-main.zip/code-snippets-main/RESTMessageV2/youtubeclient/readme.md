Example of how you can utilize the older style rest message v2 to interact with youtube data client.
Has been replaced with the newer youtube spoke, but is fun to have around and reference how it used to be done.
