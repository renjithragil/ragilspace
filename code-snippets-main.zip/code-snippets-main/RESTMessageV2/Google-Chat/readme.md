How we can use RESTMessageV2 to send notification in Google chat using Google chat webhook.

Reference link is given in the code on how we can get the Google chat webhook URL.
