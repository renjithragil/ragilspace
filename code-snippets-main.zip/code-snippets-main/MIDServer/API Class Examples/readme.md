# MIDServer class samples

* Description: Usage samples for the MIDServer API class.
* [MIDServer Code Snippet](scripts.js)
* [MIDServer API Doc](https://developer.servicenow.com/dev.do#!/reference/api/rome/server_legacy/c_MIDServerAPI)