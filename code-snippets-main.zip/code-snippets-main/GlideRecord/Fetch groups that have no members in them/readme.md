This is script is useful in listing out the groups that do not have any members. You can use it before setting any group record/s as inactive. 
