Get all user's group based on username

Just add replace the **userid** with the correct username in script
