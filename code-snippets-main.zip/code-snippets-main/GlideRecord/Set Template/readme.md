This function is useful in applying template on tables when creating new record using scripts.
