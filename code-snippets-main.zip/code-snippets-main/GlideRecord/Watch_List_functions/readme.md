This code snippet is to help you remove a specific element/sys_id from a List or an array using javascript. This code can be run via any server side scripting.
For eg:
1. Background scripting
2. Fix script
3. BR
4. ScriptInclude etc.
