# LEFT Join

This script can be used if you want to filter the results of a table based on values from a related table.

This is very useful in before query Business Rules. You can use this to filter the results based on a related table

### Examples

1. Users that like Tennis and Movies
2. Users called Patrik or that like Movies
3. Incidents with Priority 1 - Critical or SLA In Progress

