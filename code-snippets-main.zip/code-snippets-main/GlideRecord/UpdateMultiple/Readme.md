Update Multiple is such a useful tool. It has a few restrictions so make sure you are able to use it for your use case (not Journals)

