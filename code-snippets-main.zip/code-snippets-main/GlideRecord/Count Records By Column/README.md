# Count records in a table by column
Script to count records in a table, grouped by a certain column and output as CSV for further data analysis.
Can be useful where further data analysis is needed for example during data or domain migration projects.
