This piece of code will let you insert MRVS Records without quering the Question Answers out of the box table!
