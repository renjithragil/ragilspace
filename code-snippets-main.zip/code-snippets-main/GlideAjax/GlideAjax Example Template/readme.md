# GlideAjax Example Template

When you need a client to contact the server after all OnLoad scripts have concluded.

Copy and paste and just change values around.

### Changes
  * Used GlideQuery instead of GlideRecord for better performance for counting records.
  * Reducing couple of lines of code.
  * Used g_form.addInfoMessage instead of alert for showing message.
