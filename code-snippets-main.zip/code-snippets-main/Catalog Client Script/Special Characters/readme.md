# Validate Special Characters for a catalog variable

With this onChange catalog client script you can validate if there are any special characters present in the input given by user in a particular field and show an error message below the field and clear the field value. Although we have other methods to do this, it is much easier and you can customize your error message.

