# Regular Expression on Catalog Client script
  
With the help of this code you can easily validate the input value from the user and if it's not a email format you can clear and throw a error message below the variable. Of course you can use Email type variable as well but you cannot have a formatted error message.

* [Click here for script](script.js)




