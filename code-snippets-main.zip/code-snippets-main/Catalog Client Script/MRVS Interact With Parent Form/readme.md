Use this code snippet to interact with the parent form (i.e the main catalogue item) from within a catalog client script on a Multi-row variable set.

The g_service_catalog object allows for accessing the "parent" GlideForm (g_form) object and its related functions
