Before Business rule to check for existing entry in a table , incase one would want to make an insert to be unique based on a certain criteria.
