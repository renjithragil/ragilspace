This is a code snippet which can be used in a Business rule to prevent the closure of RITM when there is any active catalog task attached to that RITM.
Below are the conditions of Business rule mostly suited.
When: Before
Update: True

Note: This script is helpful for all the tables and their related tables. It can work same way by editing the table names for other parent child ralations as well.
