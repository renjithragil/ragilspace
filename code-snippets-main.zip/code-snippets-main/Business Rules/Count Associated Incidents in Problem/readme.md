<h2> Count the number of associated incidents in Problem Form </h2>
<h3>Use - Case: </h3>
<h4>Created a field in the Problem form which shows the number of incident records associated with the same problem. This makes it easy for the helpdesk to find out if there are any linked incidents without scrolling down.</h4>
