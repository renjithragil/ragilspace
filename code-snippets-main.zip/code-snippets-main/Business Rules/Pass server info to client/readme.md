This BR can be used to pass any server information to the client side using the g_scratchpad variable.

BR Type:  Display business rule

Usage Scenario: We want to apply some logic based
    - on some property value stored at the server side.
    - on the department/manager associated with the user.

 