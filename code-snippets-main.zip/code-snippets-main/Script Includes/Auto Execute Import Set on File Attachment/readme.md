# Auto Execute Import Set on File Attachment
You have to create a data source and a transform map first. After that you can use Flow Designer with the trigger condition Attachment is added to the data source. Once the flow triggers, it will call the action which in turn will trigger the Script Include to create an Import Set and Transform Map.
