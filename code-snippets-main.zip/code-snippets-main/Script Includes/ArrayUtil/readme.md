ArrayUtil API is a script include with useful functions for working with JavaScript arrays.
The example shared helps removes duplicate items from an array using the 'unique' method
