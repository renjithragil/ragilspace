var ExampleStrategy2Base = Class.create();
ExampleStrategy2Base.prototype = Object.extendsObject(AbstractStrategy, {
    initialize: function (/* expected */) {},
    run: function() {
        /**
         * do something here
         */
    },

    type: 'ExampleStrategy2Base'
});