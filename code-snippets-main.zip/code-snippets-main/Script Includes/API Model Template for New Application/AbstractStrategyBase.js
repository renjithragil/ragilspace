var AbstractStrategyBase = Class.create();
AbstractStrategyBase.prototype = Object.extendsObject(ApplicationCore, {
    initialize: function (/* expected */) {},
    run: function() {
        /**
         * do something here
         */
    },

    type: 'AbstractStrategyBase'
});