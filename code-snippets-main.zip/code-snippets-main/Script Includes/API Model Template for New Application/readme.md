# Application Baseline Pattern

Use this Script Include to extend into your new API model and provide a set of re-usable and extendable methods to enhance your application design

Create the new Script Include in your SN instance in the relevant scope, using the matching filename
Then change the name and ensure all references are updated

You can re-use and extend this pattern based on any object and centralise code in the core API base
