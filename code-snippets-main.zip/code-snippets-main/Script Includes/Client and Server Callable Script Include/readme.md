# Client and Server Callable Script Include

Example of a script include that can be called via both client and server.