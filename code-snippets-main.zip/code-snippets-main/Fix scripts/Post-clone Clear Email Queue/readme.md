# Post-clone script for email properties

To be used as a fix script or background script, meant to help with small adjustments needed per-environment after a clone.

Notes: Make sure you fill in all of the instance names up top, with anything in your instance name before the [.service-now.com]

This clears out the email queue.