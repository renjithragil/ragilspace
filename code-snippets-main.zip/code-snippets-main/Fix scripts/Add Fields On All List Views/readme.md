# Add Fields On All List Views

This will add Updated On, Updated By, Created on, and Created by to every list view for the current user. You can add or remove fields to fieldsToAdd if you want others added as well
