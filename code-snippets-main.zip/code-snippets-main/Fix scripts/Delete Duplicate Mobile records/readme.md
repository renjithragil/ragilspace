Below script is a Fix script used to delete duplicate mobile assets and Cis in your CMDB. In this script we keep recently created assets and its related CI and delete other duplicate assets and related Cis if any.

Note : In this script I have used u_alm_mobile as the table and u_cmdb_ci_mobile, this are my tables but you can use your own table where you have stored your mobile devices.

