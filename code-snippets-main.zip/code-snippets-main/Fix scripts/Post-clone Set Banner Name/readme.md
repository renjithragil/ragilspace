# Post-clone script for email properties

To be used as a fix script or background script, meant to help with small adjustments needed per-environment after a clone.

Notes: Make sure you fill in all of the instance names up top, with anything in your instance name before the [.service-now.com]

This sets the banner description (that appears at the top of the instance) to the instance name and the date/time of the last clone. Helps keep users of that sub-prod instance informed of when the last clone date/time.