Used to ignore all emails in the system so they are not sent on outbox activation. 
Run this script prior to enabling email sending to ensure no testing emails are sent upon email activation
