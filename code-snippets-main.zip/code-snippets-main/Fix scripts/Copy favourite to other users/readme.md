You can use this script to take an existing favaourite from the sys_ui_bookmark table and create a copy of it for any number of users.
Can be useful when onboarding new staff, doing testing, etc.

You will need two things to get started:
* the sys_id of the original favourite you want to copy - take this from sys_ui_bookmark table
* an ecoded query string of a filtered list of users that you want to copy the favourite to

Run the script wherever you like, background script, Xplore, or as fix script.
Have fun!
