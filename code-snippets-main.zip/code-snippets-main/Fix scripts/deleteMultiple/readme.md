This script is recommended to be used (with caution) when it's necessary to delete multiple records from a table.

deleteMultiple is considerably faster than deleteRecord

As stated in the script, it's important to limit the amount of records being processed by this script at a time and never test this on Production without doing so on Development first
