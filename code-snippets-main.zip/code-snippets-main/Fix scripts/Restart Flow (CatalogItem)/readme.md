# Restart a Catalog Item Flow

To be used as a fix script or background script to restart a flow for a catalog item or selection of catalog items.  Typically this might be used in a scenarion in which you've modified a Flow and need to ensure that existing items are running the current version of the flow.

Note: This will RESTART your flows from the beginning.  So if your item is in progress you may see some undesirable behavior.  Also keep in mind any notifications you may have set to fire from the Flow.
